﻿[string]$location = Join-Path $env:ProgramFiles 'DSC-EA'
[string]$webstyle = @'
<style>
BODY{background-color:#0078D7; margin-left:50px; margin-right:auto;}
TABLE{border-width:1px; border-style:solid; border-color:black; border-collapse:collapse; color:black;}
TH{border-width:1px; padding:5px; border-style:solid; border-color:black; background-color:white; color:#12233D; font-family:Segoe UI;}
TD{border-width:1px; padding:5px; border-style:solid; border-color:black; background-color:#FCEBDA; font-family:Arial;}
titlesection{color:white; font-family:Segoe UI; font-size:32px; font-weight:bold;}
datesection{color:white; font-family:Segoe UI;}
</style>
'@

filter Export-SQL {
    Begin {
        #Open SQL Connection
    }
    Process {
        #Insert Statement for each Object
    }
    End {
        #Close SQL Connection
        #Save maybe?
    }
}

function helper-DataFileMustExist {
    if(-not (Test-Path $env:ProgramFiles\DSC-EA\computers.xml)){
        $data = @{
            AllNodes = @()
            NonNodeData = ''
        }
        $data | Export-Clixml $env:ProgramFiles\DSC-EA\computers.xml
    }
}

function helper-GetNewestXML {
    Get-ChildItem $location\Output\results*.xml | Sort-Object -Property LastWriteTime -Descending | Select -First 1
}

function helper-EnsureLogo {
    if(-not (Test-Path $location\Output\logo.png))
    {
        $env:PSModulePath -split ';' | ForEach-Object {
            if(Test-Path (Join-Path $_ 'DSCEA\Output\logo.png')) {
                Copy-Item (Join-Path $_ 'DSCEA\Output\logo.png') $location\Output\logo.png
            }
        }
    }
}

function Add-DscEaComputer {
    <#
.Synopsis
   This function adds a new computer to the computers.xml data file
.DESCRIPTION
   Long description
.EXAMPLE
   Add-DscEaComputer -ComputerName Test1
.EXAMPLE
   Add-DscEaComputer -ComputerName Test1, Test2 -Groups 'Test Group'
.EXAMPLE
   $computerlist | Add-DscEaComputer -Groups 'Group X'
.INPUTS
   Inputs to this cmdlet (if any)
.OUTPUTS
   Output from this cmdlet (if any)
.NOTES
   General notes
.COMPONENT
   The component this cmdlet belongs to
.ROLE
   The role this cmdlet belongs to
.FUNCTIONALITY
   The functionality that best describes this cmdlet
#>
    [CmdletBinding()]
    [OutputType([String])]
    Param
    (
        [Parameter(Mandatory=$true, 
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true, 
                   Position=0)]
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [String[]]
        $ComputerNames,

        [Parameter()]
        [AllowNull()]
        [AllowEmptyCollection()]
        [AllowEmptyString()]
        [String[]]
        $Groups
    )
    Begin
    {
        Helper-dataFileMustExist
        $data = Import-Clixml -Path $env:ProgramFiles\DSC-EA\computers.xml
    }
    Process
    {
        $ComputerNames | ForEach-Object {
            $data.AllNodes += @{
                NodeName = $_
                Groups = $Groups
            }
        }
    }
    End
    {
        $data | Export-Clixml -Path $env:ProgramFiles\DSC-EA\computers.xml
    }
}

function Remove-DscEaComputer {
    <#
.Synopsis
   This function adds a new computer to the computers.xml data file
.DESCRIPTION
   Long description
.EXAMPLE
   Example of how to use this cmdlet
.EXAMPLE
   Another example of how to use this cmdlet
.INPUTS
   Inputs to this cmdlet (if any)
.OUTPUTS
   Output from this cmdlet (if any)
.NOTES
   General notes
.COMPONENT
   The component this cmdlet belongs to
.ROLE
   The role this cmdlet belongs to
.FUNCTIONALITY
   The functionality that best describes this cmdlet
#>
    [CmdletBinding()]
    [OutputType([String])]
    Param
    (
        [Parameter(Mandatory=$true, 
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true, 
                   Position=0)]
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [String[]]
        $ComputerName
    )
    Begin
    {
        Helper-dataFileMustExist
        $data = Import-Clixml -Path $env:ProgramFiles\DSC-EA\computers.xml
    }
    Process
    {
        #Still buggy, doesn't remove properly - find efficient way to remove single array node matching hashtable value nodename
        $ComputerName | ForEach-Object {
            $Computer = $_
            $data.AllNodes | ForEach-Object {$i=0} {
                if($_.NodeName -eq $Computer) {
                    $data.allnodes.RemoveAt($i)
                    break;
                }
                $i++
            }
        }
    }
    End
    {
        $data | Export-Clixml -Path $env:ProgramFiles\DSC-EA\computers.xml
    }
}

function Get-DscEaComputer {
    <#
.Synopsis
   Short description
.DESCRIPTION
   Long description
.EXAMPLE
   Example of how to use this cmdlet
.EXAMPLE
   Another example of how to use this cmdlet
#>
    [CmdletBinding()]
    [Alias()]
    [OutputType([Hashtable])]
    Param
    (
        # Param1 help description
        #[Parameter(Mandatory=$true,
        #           ValueFromPipelineByPropertyName=$true,
        #           Position=0)]
        #$Param1,
        #
        ## Param2 help description
        #[int]
        #$Param2
    )

    Begin
    {
        Helper-dataFileMustExist
        $data = Import-Clixml -Path $env:ProgramFiles\DSC-EA\computers.xml
    }
    Process
    {
        $data.AllNodes | ForEach-Object {
            [PSCustomObject]@{
                Name = $_.NodeName
                Groups = $_.Groups
            }
        }
    }
    End
    {
    }
}

function Start-DscEaScan {
<#   
.SYNOPSIS   
Will run Test-DscConfiguration -ReferenceConfiguration against the remote systems listed in $env:ProgramFiles\DSC-EA\computers.ps1 and saves the results to a XML file in $env:ProgramFiles\DSC-EA\Output

.DESCRIPTION 
Run this function after you have a list of remote systems to scan and a localhost.MOF file created that defines the settings you want to check against.

.NOTES   

.LINK
http://aka.ms/dscea

.EXAMPLE
. Start-DscEaScan
#>
[CmdletBinding()]
param
    (
        [ValidateNotNullOrEmpty()]
        [string]$OutputPath = (Join-Path $location 'Output'),

        [ValidateNotNullOrEmpty()]
        [string]$MofFile = (Join-Path $location 'localhost.mof'),

        [ValidateNotNullOrEmpty()]
        [string]$ComputersFile = (Join-Path $location 'computers.ps1'),

        [ValidateNotNullOrEmpty()]
        [string]$JobTimeout = 600,

        [ValidateNotNullOrEmpty()]
        [string]$ScanTimeout = 3600,

        [boolean]$ForceScan = $False,

        [ValidateNotNullOrEmpty()]
        [string]$ResultsFile = (Join-Path $OutputPath "results.$(Get-Date -Format 'yyyyMMdd-HHmm-ss').xml"),

        [Microsoft.Management.Infrastructure.CimSession[]]$CimSession,

        [string[]]$ComputerName
    )

    #Begin Output Directory Creation
    if (Test-Path $OutputPath) {
    } 
    else {
        New-Item $OutputPath -ItemType Directory
    }
    #End Output Directory Creation

    #Begin DSC-EA Engine
    $runspacePool = [RunspaceFactory]::CreateRunspacePool(1, 10).Open() #Min Runspaces, Max Runspaces
    $scriptBlock = {
        param (
            [ValidateNotNullOrEmpty()]
            [string]$computer,

            [ValidateScript({Test-Path $_ })]
            [string]$mofFile,

            [ValidateNotNullOrEmpty()]
            [string]$JobTimeout,

            [boolean]$ForceScan = $False,

            [Microsoft.Management.Infrastructure.CimSession]$CimSession
            )

        function KillDSCEngine{
        [CmdletBinding()]
        param
            (
                [ValidateNotNullOrEmpty()]
                [string[]]$ComputerName
            )
        
                #kill the dsc processes on the remote system
                Invoke-Command -ComputerName $ComputerName -ScriptBlock {
                ### find the process that is hosting the DSC engine
                $dscProcessID = Get-WmiObject msft_providers | 
                Where-Object {$_.provider -like 'dsccore'} | 
                Select-Object -ExpandProperty HostProcessIdentifier 
                ### Stop the process
                Get-Process -Id $dscProcessID | Stop-Process -Force
                } -ErrorAction SilentlyContinue
        }

        $runTime = Measure-Command {
        try
        {
        if ($ForceScan) {
        #executed twice, we have noticed sometimes the first attempt does not actually kill the DSC engine and release the consistency check, this will be fixed in a later version
        KillDSCEngine -ComputerName $computer -ErrorAction SilentlyContinue
        KillDSCEngine -ComputerName $computer -ErrorAction SilentlyContinue
        }
        
            $DSCJob = Test-DSCConfiguration -ReferenceConfiguration $mofFile -CimSession $computer -AsJob | Wait-Job -Timeout $JobTimeout

            if (!$DSCJob) { 
            $JobFailedError = "$computer was unable to complete in the alloted job timeout period of $JobTimeout seconds"
            KillDSCEngine -ComputerName $computer
            KillDSCEngine -ComputerName $computer
            return
            }

            $compliance = Receive-Job $DSCJob -ErrorVariable JobFailedError
            Remove-Job $DSCJob
                       
        }
        catch
        {
            $JobFailedError = $_
        }
      
    }

    return [PSCustomObject]@{
        Computer = $computer
        RunTime = $runTime
        Compliance = $compliance
        Exception = $JobFailedError
        }
    }
    $scriptBlock2 = {
        param (
            [ValidateScript({Test-Path $_ })]
            [string]$mofFile,

            [Microsoft.Management.Infrastructure.CimSession]$CimSession
            )

        function KillDSCEngine{
        [CmdletBinding()]
        param
            (
                [ValidateNotNullOrEmpty()]
                [string[]]$ComputerName
            )
        
                #kill the dsc processes on the remote system
                Invoke-Command -ComputerName $ComputerName -ScriptBlock {
                ### find the process that is hosting the DSC engine
                $dscProcessID = Get-WmiObject msft_providers | 
                Where-Object {$_.provider -like 'dsccore'} | 
                Select-Object -ExpandProperty HostProcessIdentifier 
                ### Stop the process
                Get-Process -Id $dscProcessID | Stop-Process -Force
                } -ErrorAction SilentlyContinue
        }

        $runTime = Measure-Command {
        try
        {       
            $compliance = Test-DSCConfiguration -ReferenceConfiguration $mofFile -CimSession $CimSession        
        }
        catch
        {
            $JobFailedError = $_
        }
      
    }

    return [PSCustomObject]@{
        Computer = $CimSession.ComputerName
        RunTime = $runTime
        Compliance = $compliance
        Exception = $JobFailedError
        }
    }
    $jobs = @()
    $results = @()
    #introduce while logic here as well or recommend apply-once lcm
    #replace invoke-command with runspaces
    Write-Verbose "Testing connectivity and PowerShell version of remote systems`n(All Systems must be running PowerShell 5)"
    
    if($PSBoundParameters.ContainsKey('CimSession'))
    {
        $cimsession | ForEach-Object {
            $job = [Powershell]::Create().AddScript($ScriptBlock2).AddArgument($MofFile).AddArgument($_)
            Write-Host ("Initiating DSC-EA scan on " + $_.ComputerName)
		    $job.RunSpacePool = $runspacePool
            $jobs += [PSCustomObject]@{
                    Pipe = $job
                    Result = $job.BeginInvoke()
            }
        }
    }
    else
    {
        if($PSBoundParameters.ContainsKey('ComputerName')){
        $firstrunlist = $ComputerName
        }
        else {
            $firstrunlist = (Get-Content $ComputersFile)
        }

        $psresults = Invoke-Command -ComputerName $firstrunlist -ScriptBlock {
            $PSVersionTable.PSVersion
        } -ErrorVariable ConnectionFailureErrors -ErrorAction SilentlyContinue

        $runlist =  ($psresults | where-object -Property Major -ge 5).PSComputername
        $versionerrorlist =  ($psresults | where-object -Property Major -lt 5).PSComputername

        $PSVersionErrorsFile = (Join-Path $OutputPath "PSVersionErrors.$(Get-Date -Format 'yyyyMMdd-HHmm-ss').xml")
        $ConnectionFailureErrorsFile = (Join-Path $OutputPath "ConnectionFailureErrors.$(Get-Date -Format 'yyyyMMdd-HHmm-ss').xml")
    
        Write-Verbose "Connectivity testing complete"
        if ($versionerrorlist){
        Write-Warning "The following systems cannot be scanned as they are not running PowerShell 5.  Please check '$versionerrorlist' for details"
        }
        $RunList | Sort-Object | ForEach-Object {
            $job = [Powershell]::Create().AddScript($scriptBlock).AddArgument($_).AddArgument($MofFile).AddArgument($JobTimeout).AddArgument($ForceScan)
            Write-Host "Initiating DSC-EA scan on $_"
		    $job.RunSpacePool = $runspacePool
            $jobs += [PSCustomObject]@{
                    Pipe = $job
                    Result = $job.BeginInvoke()
            }
        }
    }

    
    #Wait for Jobs to Complete
    Write-Verbose "Processing Compliance Testing..."
    $overalltimeout = new-timespan -Seconds $ScanTimeout
    $elapsedTime = [system.diagnostics.stopwatch]::StartNew()
    do {
       #Write-Host "." -NoNewline
       Start-Sleep -Milliseconds 500
       $jobscomplete = ($jobs.result.iscompleted | where {$_ -eq $true}).count
       write-progress -activity "Working..." -PercentComplete (($jobscomplete / $jobs.count)*100) -status "$([string]::Format("Time Elapsed: {0:d2}:{1:d2}:{2:d2}     Jobs Complete: {3} of {4} ", $elapsedTime.Elapsed.hours, $elapsedTime.Elapsed.minutes, $elapsedTime.Elapsed.seconds, $jobscomplete, $jobs.count))";
       #pecentage complete can be added as the number of jobs completed out of the number of total jobs
       #write-host ($jobs.Result.IsCompleted)
       if ($elapsedTime.elapsed -gt $overalltimeout) {
       Write-Host "The DSC-EA scan was unable to complete because the timeout value of" $overalltimeout.TotalSeconds "seconds was exceeded." -ForegroundColor Red
       return
       }
    } while (($jobs.Result.IsCompleted -contains $false) -and ($elapsedTime.elapsed -lt $overalltimeout)) #while elasped time < 1 hour by default

    #Retrieve Jobs
    $jobs | ForEach-Object {
        $results += $_.Pipe.EndInvoke($_.Result)
    }

    #ForEach ($exceptionwarning in $results.Exception) {
    #    Write-Warning $exceptionwarning
    #}

    #Save Results
    Write-Host "Writing results to '$ResultsFile'"
    "$([string]::Format("Total Scan Time: {0:d2}:{1:d2}:{2:d2}", $elapsedTime.Elapsed.hours, $elapsedTime.Elapsed.minutes, $elapsedTime.Elapsed.seconds))"
    $results | Export-Clixml -Path $ResultsFile -Force

    if ($ConnectionFailureErrors){
    Write-Warning "The DSC-EA scan completed but did not scan all systems.  Please check '$ConnectionFailureErrorsFile' for details"
    $ConnectionFailureErrors | Export-Clixml -Path $ConnectionFailureErrorsFile -Force
    }

    if ($versionerrorlist){ #currently presents an ugly divide by zero message if the only systems in the list are below PowerShell 5
    #add in comma separated option for multiple systems
    Write-Warning "The DSC-EA scan completed but did not scan all systems.  Please check '$PSVersionErrorsFile' for details"
    $versionerrorlist | Export-Clixml -Path $PSVersionErrorsFile -Force
    }

    #if ($results.Exception){
    #Write-Warning "The DSC-EA scan completed but job errors were detected.  Please check '$ResultsFile' for details"
    #}

}

function New-DscEaSampleComputers {
<#   
.SYNOPSIS   
Creates sample configuration file for computers.ps1

.DESCRIPTION 
Creates computers.ps1 in Program Files\DSCEA folder

.LINK
htt://aka.ms/dscea
#>
    if(Test-Path $location\computers.ps1){
        Write-Host "$location\computers.ps1 already exists"
    }
    else { 
		New-Item -force -ItemType File -Path $location\computers.ps1
		Set-Content $location\computers.ps1 "DSCTEST01`r`nDSCTEST02"

		$stream = [IO.File]::OpenWrite('C:\Program Files\DSC-EA\computers.ps1')
		$stream.SetLength($stream.Length - 2)
		$stream.Close()
		$stream.Dispose()      
    }
}

function New-DscEaSampleConfigs {
<#   
.SYNOPSIS   
Creates sample configuration file SampleConfig.ps1

.DESCRIPTION 
Creates SampleConfig.ps1 in Program Files\DSCEA folder

.LINK
htt://aka.ms/dscea
#>
    if(Test-Path $location\SampleConfig.ps1){
        Write-Host "$location\SampleConfig.ps1 already exists"
    }
    else {
@'
configuration MemberServerSecuritySettings {

    param(
        [string[]]$ComputerName="localhost"
    )
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Node $ComputerName {   
    
    #Anti-Malware
        Service MicrosoftAntimalwareService{
        Name = "MsMpSvc"
        StartupType = "Automatic"
        State = "Running"
        }
    
    #User Account Control
        Registry ConsentPromptBehaviorAdmin{
        Ensure = "Present"
        Key = "HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System"
        ValueName = "ConsentPromptBehaviorAdmin"
        ValueType = "Dword"
        ValueData = "5"
        }  

        Registry PromptOnSecureDesktop{
        Ensure = "Present"
        Key = "HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System"
        ValueName = "PromptOnSecureDesktop"
        ValueType = "Dword"
        ValueData = "1"
        }

	#Interactive logon: Number of previous logons to cache (in case domain controller is not available)
        Registry Numberofpreviouslogonstocache{
        Ensure = "Present"
        Key = "HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion\Winlogon"
        ValueName = "CachedLogonsCount"
        ValueType = "Dword"
        ValueData = "2"
        }

    #Checks to ensure that certain Windows Roles or Windows Features have not been installed
        WindowsFeature ActiveDirectoryDomainServices{
            Name = 'AD-Domain-Services'
            Ensure = 'Absent'
        }
	
		WindowsFeature DNSServer{
            Name = 'DNS'
            Ensure = 'Absent'
        }
    
	    WindowsFeature DHCPServer{
            Name = 'DHCP'
            Ensure = 'Absent'
        }

		WindowsFeature WindowsRoleFax{
            Name = 'Fax'
            Ensure = 'Absent'
        }

		#WindowsFeature TelnetServer {
        #    Name = 'Telnet-Server'
        #    Ensure = 'Absent'
        #}

        }
		        
}

MemberServerSecuritySettings -OutputPath $env:ProgramFiles\DSC-EA

#Uncomment the following code to replace the default call to MemberServerSecuritySettings shown above if you would like to generate machine specific MOF files.  Then comment out the default call above.

#    ForEach ($system in (Get-Content $env:ProgramFiles\DSC-EA\computers.ps1))
#    {
#      MemberServerSecuritySettings -OutputPath $env:ProgramFiles\DSC-EA -ComputerName $system
#    }
'@ | Set-Content -Path $location\SampleConfig.ps1 -Force
    }
    if(Test-Path $location\SampleApplyConfig.ps1){
        Write-Host "$location\SampleApplyConfig.ps1 already exists"
    }
    else {
@'
param([parameter(mandatory=$true,position=1)][string[]]$Computers)
configuration MemberServerSecuritySettings {

    param(
        [string[]]$ComputerName="localhost"
    )
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Node $ComputerName {   
       
    #User Account Control
        Registry ConsentPromptBehaviorAdmin{
        Ensure = "Present"
        Key = "HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System"
        ValueName = "ConsentPromptBehaviorAdmin"
        ValueType = "Dword"
        ValueData = "5"
        }  

        Registry PromptOnSecureDesktop{
        Ensure = "Present"
        Key = "HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System"
        ValueName = "PromptOnSecureDesktop"
        ValueType = "Dword"
        ValueData = "1"
        }

	#Interactive logon: Number of previous logons to cache (in case domain controller is not available)
        Registry Numberofpreviouslogonstocache{
        Ensure = "Present"
        Key = "HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion\Winlogon"
        ValueName = "CachedLogonsCount"
        ValueType = "Dword"
        ValueData = "2"
        }
    }	        
}

$Computers | ForEach-Object {
    MemberServerSecuritySettings -OutputPath $env:ProgramFiles\DSC-EA -ComputerName $_
}
'@ | Set-Content -Path $location\SampleApplyConfig.ps1 -Force
    }
}

function Get-DscEaReport {
<#   
.SYNOPSIS   
Generate a report after Start-DscEaScan has been run

.DESCRIPTION 
Used to create viewable reports after Start-DscEaScan has created a results.xml file which will be parsed 

.PARAMETER ItemName
This is the item name from the configuration file, used to generate a report of every machine's compliance against that item

.PARAMETER ComputerName
The computer name here will cause the report to display all items (true/false) pertaining to ComputerName

.PARAMETER Overall
Switch parameter indicating that the report generated will display true/false per computer in regards to the entire configuration file

.PARAMETER Detailed
Switch parameter indicating that the report generated will display true/false per configuration file item, per computer

.LINK
http://aka.ms/dscea

.EXAMPLE
Get-DscEaReport -ItemName MicrosoftAntimalwareService

Description
-----------
This command returns all systems in computer.txt and if Microsoft AntiMalware Service is configured correctly

.EXAMPLE
Get-DscEaReport -ComputerName 'dc1'

Description
-----------
This command returns all configuration items for computer 'dc1'

.EXAMPLE
Get-DscEaReport -Overall

Description
-----------
This command returns true/false per machine if they comply with the entire configuration file

.EXAMPLE
Get-DscEaReport -Detailed

Description
-----------
This command returns true/false per configuration item, per machine
#>
    [CmdLetBinding()]
    param
    (
        [parameter(Mandatory = $true , ParameterSetName = 'Item')]
        [String]$ItemName,

        [parameter(Mandatory = $true , ParameterSetName = 'Computer')]
        [String]$ComputerName,

        [parameter(Mandatory=$true , ParameterSetName='Overall')]
        [switch]$Overall,

        [parameter(Mandatory = $true , ParameterSetName = 'Detailed')]
        [switch]$Detailed,

        [String]$InFile = (helper-GetNewestXML).FullName,

        [String]$OutPath = "$env:ProgramFiles\DSC-EA\Output"
    )
    helper-EnsureLogo
    $results = Import-Clixml $InFile
    $date = (Get-ChildItem $InFile).LastWriteTime
    if($Overall){
        $results | 
        select-object -ExpandProperty Compliance | 
        select @{Name="Computer";Expression={$_.PSComputerName}}, @{Name="Compliant";Expression={$_.InDesiredState}} |
        ConvertTo-HTML -Head $webstyle -body "<img src='logo.png'/><br>","<titlesection>DSC Configuration Report</titlesection><br>","<datesection>Report last run on",$date,"</datesection><p>" | 
        Out-File $env:ProgramFiles\DSC-EA\Output\OverallComplianceReport.html
        Write-Host "Report $OutPath\OverallComplianceReport.html generated"
    }
    if($Detailed){
        $results | % {
            $_.Compliance | % {
        $_.ResourcesNotInDesiredState | 
        Select-Object @{Name="Computer";Expression={$_.PSComputerName}}, ResourceName, InstanceName, InDesiredState
        }
    } | ConvertTo-HTML -Head $webstyle -body "<img src='logo.png'/><br>","<titlesection>DSC Configuration Report</titlesection><br>","<datesection>Report last run on",$date,"</datesection><p>" | 
    Out-File $env:ProgramFiles\DSC-EA\Output\DetailedComplianceReport.html 
    Write-Host "Report $OutPath\DetailedComplianceReport.html generated"
    }
    if($ItemName){
        $results | % {
            $_.Compliance | % {
                $_.ResourcesInDesiredState | % {$_ | Select-Object @{Name="Computer";Expression={$_.PSComputerName}}, ResourceName, InstanceName, InDesiredState}
                $_.ResourcesNotInDesiredState | % {$_ | Select-Object @{Name="Computer";Expression={$_.PSComputerName}}, ResourceName, InstanceName, InDesiredState}
            }
        } | Where-object {$_.InstanceName -ieq $ItemName} | 
        ConvertTo-HTML -Head $webstyle -body "<img src='logo.png'/><br>","<titlesection>DSC Configuration Report</titlesection><br>","<datesection>Report last run on",$date,"</datesection><p>" | 
        Out-File $OutPath\ItemComplianceReport-$ItemName.html
        Write-Host "Report $OutPath\ItemComplianceReport-$ItemName.html generated"
    }
    if($ComputerName){
        $results | where-object {$_.Computer -ieq $ComputerName} | % {
            $_.Compliance | % {
                $_.ResourcesNotInDesiredState | Select-Object @{Name="Computer";Expression={$_.PSComputerName}}, ResourceName, InstanceName, InDesiredState
                $_.ResourcesInDesiredState | Select-Object @{Name="Computer";Expression={$_.PSComputerName}}, ResourceName, InstanceName, InDesiredState
            }
        } | ConvertTo-HTML -Head $webstyle -body "<img src='logo.png'/><br>","<titlesection>DSC Configuration Report</titlesection><br>","<datesection>Report last run on",$date,"</datesection><p>" | Out-File $OutPath\ComputerComplianceReport-$ComputerName.html 
        Write-Host "Report $OutPath\ComputerComplianceReport-$ComputerName.html generated"
    }
}

function Get-DscEaPowerBiReport {
    [CmdLetBinding()]param(
    [String]$OutPath = "$env:ProgramFiles\DSC-EA\Output"
)
    Set-Location $OutPath

    if(Test-Path ..\Groupings\ComputerGroups.psd1) {
        $ComputerHT = Invoke-Expression (Get-Content ..\Groupings\ComputerGroups.psd1 | Out-String)
    }
    if(Test-Path ..\Groupings\ItemGroups.psd1) {
        $ItemHT = Invoke-Expression (Get-Content ..\Groupings\ItemGroups.psd1 | Out-String)
    }

    #Get-ChildItem -Path $OutPath -Filter '*.xml' | where-object -property LastWriteTime -gt (Get-ChildItem .\PowerBiResults.csv).LastWriteTime.AddDays(1)
   
    (Get-ChildItem -Path $OutPath -Filter '*.xml' | Sort-Object LastWriteTime -Descending)[0] | ForEach-Object {
        $results = Import-CliXml $_
    $newdata = $results | ForEach-Object {
            $_.Compliance | ForEach-Object {
            if($_.ResourcesInDesiredState) {
                $_.ResourcesInDesiredState | ForEach-Object {
                    $_ | Add-Member -NotePropertyName "ComputerGroup" -NotePropertyValue $ComputerHT.($_.PSComputerName) -Force
                    $_ | Add-Member -NotePropertyName "ItemGroup" -NotePropertyValue $ItemHT.($_.InstanceName) -Force
                    $_
                                                }
                }
            if($_.ResourcesNotInDesiredState) {
                $_.ResourcesNotInDesiredState | ForEach-Object {
                    $_ | Add-Member -NotePropertyName "ComputerGroup" -NotePropertyValue $ComputerHT.($_.PSComputerName) -Force
                    $_ | Add-Member -NotePropertyName "ItemGroup" -NotePropertyValue $ItemHT.($_.InstanceName) -Force
                    $_
                                                }
                }
            }
        }
    }
    $parsedData = $newdata | Select-Object PSComputerName, ResourceName, InstanceName, InDesiredState, ConfigurationName, StartDate, ComputerGroup, ItemGroup
    if(Test-Path .\DAY.CSV) {
        if(Test-Path .\ALL.CSV) {
            if((Get-ChildItem -Path .\ALL.CSV).LastWriteTime -lt (Get-Date).AddDays(-1)) {
                Import-Csv -Path .\DAY.CSV | Export-Csv -Path .\ALL.CSV -Append
                $parsedData | Export-Csv -Path $OutPath\DAY.CSV -NoTypeInformation
            }
            else {
                $parsedData | Export-Csv -Path $OutPath\DAY.CSV -NoTypeInformation
            }
        } else {
            Rename-Item -Path .\DAY.CSV -NewName .\ALL.CSV
            $parsedData | Export-Csv -Path $OutPath\DAY.CSV -NoTypeInformation
        }       
    }
    else {
        $parsedData | Export-Csv -Path $OutPath\DAY.CSV -NoTypeInformation
    }
}

function Start-DscEaApplyConfiguration {
<#   
.SYNOPSIS   
Will create machine specific MOFs and apply settings to remote systems

.PARAMETER ConfigurationFile
This specifies the .ps1 script containing the Configuration keyword and settings to apply

.PARAMETER RemoteServers
This can be a single computer name or an array of computer names which will have their settings applied

.PARAMETER OutPath
Specifies the location of the machine-specific MOF file(s)

.LINK
http://aka.ms/dscea

.EXAMPLE
Start-DscApplyConfiguration -RemoteServers 'dc1','server2'

Description
-----------
Will look in Program Files\DSCEA to find SampleConfig.ps1, create machine specific MOF files for dc1 and server2, then apply them remotely
#>
    [CmdLetBinding()]
    param
    (
        [String]$ConfigurationFile="$location\SampleApplyConfig.ps1",
        [String[]]$remoteservers=(Get-Content "$location\computers.ps1"),
        [String]$OutPath=$location
    )
    Set-Location $location
    .\SampleApplyConfig.ps1 $remoteservers
    Start-DscConfiguration -Path $OutPath -ComputerName $remoteservers -Wait -Force
}

Export-ModuleMember Add-*
Export-ModuleMember Remove-*
Export-ModuleMember Get-*
Export-ModuleMember Set-*
Export-ModuleMember New-*
Export-ModuleMember Start-*